package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class JobDescriptionTab extends AppCompatActivity {
Button up;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_description_tab);

    up = findViewById(R.id.upfiles);

    up.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(JobDescriptionTab.this,FirebaseFileUpload.class));
            finish();
        }
    });

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(JobDescriptionTab.this,JobLists.class));
        finish();
    }
}