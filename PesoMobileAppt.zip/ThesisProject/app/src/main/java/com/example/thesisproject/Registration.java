package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class Registration extends AppCompatActivity {
Spinner roles,gender;
Button cancel,register;
TextInputEditText fullname,age,contact,email,address,username,password;
String role;
RadioGroup rg;
final LoadBar loadBar = new LoadBar(Registration.this);
boolean valid = true;
FirebaseAuth mAuth;


    public boolean checkField(TextInputEditText fields){
        if(fields.getText().toString().isEmpty()){
            fields.setError("Empty!");
            valid = false;
        }else{
            valid = true;
        }
        return valid;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    final ProgressBar progressBar = findViewById(R.id.progress_reg);

    rg = findViewById(R.id.radio_grp);
    roles = findViewById(R.id.role_values);
    cancel = findViewById(R.id.cancel_btn);
    register = findViewById(R.id.register_now);
    fullname = findViewById(R.id.fullname_field);
    age =findViewById(R.id.age_field);
    contact = findViewById(R.id.contact_field);
    email = findViewById(R.id.email_field);
    address  = findViewById(R.id.address_field);
//   role = roles.getSelectedItem().toString();
    password = findViewById(R.id.password_field);


    DAOUserData daoUserData = new DAOUserData();

    register.setOnClickListener(new View.OnClickListener() {

        @SuppressLint("ResourceType")
        @Override
        public void onClick(View v) {
        checkField(fullname);
        checkField(age);
        checkField(contact);
        checkField(email);
        checkField(address);
        checkField(password);


        if(valid){

            progressBar.setVisibility(View.VISIBLE);
            register.setVisibility(View.INVISIBLE);
            cancel.setVisibility(View.INVISIBLE);

            String gend = "";
            if(rg.getCheckedRadioButtonId() == 2131230987 ){
                gend= "Male";
            }else  if(rg.getCheckedRadioButtonId() == 2131230922){
                gend = "Female";
            }

//          try{
//              UserValues userValues = new UserValues(
//                           dataInput(fullname),Integer.parseInt(dataInput(age)),
//                           dataInput(contact),gend,dataInput(address)
//                      ,dataInput(email),dataInput(password),roles.getSelectedItem().toString());
//
//                   daoUserData.add(userValues).addOnSuccessListener(suc->{
//                       loadBar.startLoadingDialog();
//                       Handler handler = new Handler();
//                       handler.postDelayed(new Runnable() {
//                           @Override
//                           public void run() {
//                               loadBar.dismissDialog();
//                               Intent intent = new Intent(Registration.this,Landing.class);
//                               startActivity(intent);
//                               finish();
//                           }
//                       },3500);
//                   }).addOnFailureListener(er->{
//                       Toast.makeText(Registration.this,er.getMessage(),Toast.LENGTH_SHORT).show();
//                   });
//          }catch(Exception e ){
//              Toast.makeText(Registration.this,e.getMessage(),Toast.LENGTH_LONG).show();
//          }


        }

        }
    });

    cancel.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(Registration.this,Landing.class));
            finish();
        }
    });
   ArrayAdapter<CharSequence> rolesAdapter = ArrayAdapter.createFromResource(this,
   R.array.roles_present, android.R.layout.simple_spinner_item);
        rolesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
   roles.setAdapter(rolesAdapter);
    }
    public  String dataInput(TextView t){
        return t.getText().toString().trim();
    }
}