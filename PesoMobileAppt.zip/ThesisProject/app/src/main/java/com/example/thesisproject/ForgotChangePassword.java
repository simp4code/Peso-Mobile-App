package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import java.util.HashMap;

public class ForgotChangePassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_change_password);

        DAOUserData daoUserData = new DAOUserData();



        HashMap<String,Object> hashMap = new HashMap<>();
        hashMap.put("password","");


//        daoUserData.update("key",hashMap).addOnSuccessListener(suc->{
//
//        }).addOnFailureListener(er->{
//            Toast.makeText(ForgotChangePassword.this,er.getMessage(),Toast.LENGTH_SHORT).show();
//        });

    }
}