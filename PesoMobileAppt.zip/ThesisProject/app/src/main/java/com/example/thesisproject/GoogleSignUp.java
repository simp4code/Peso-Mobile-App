package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GoogleSignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_sign_up);
    }
}