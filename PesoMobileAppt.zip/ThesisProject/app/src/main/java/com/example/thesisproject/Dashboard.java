package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Dashboard extends AppCompatActivity {
    private int READ_STORAGE_CODE = 1;
    private int WRITE_STORAGE_CODE = 1;


    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    FirebaseAuth mAuth;
    TextView nameOfUser, noneActivity;
    ImageView picOfUser;
    Button lg;
    RecyclerView rcUser;

    final LoadBar loadBar = new LoadBar(Dashboard.this);
    final LoadImageFromGoogleAccount loadImg = new LoadImageFromGoogleAccount(Dashboard.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        noneActivity = findViewById(R.id.user_activity_none);
        rcUser = findViewById(R.id.user_activity);
        noneActivity.setVisibility(View.VISIBLE);
        rcUser.setVisibility(View.INVISIBLE);


        if (ContextCompat.checkSelfPermission(Dashboard.this,
                Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(Dashboard.this, "Permission granted", Toast.LENGTH_SHORT).show();

        } else {
            requestStoragePermission();
        }

        Intent fromLoggedInUser = getIntent();
        String name = fromLoggedInUser.getStringExtra("userName");
//        nameOfUser.setText(name);


        mAuth = FirebaseAuth.getInstance();
        nameOfUser = findViewById(R.id.fullnamevalue);
        picOfUser = findViewById(R.id.photoFromGoogle);
        setUpToolbar();
        navigationView = (NavigationView) findViewById(R.id.navigation_menu);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

        Intent fromLogin = getIntent();
        String fnFromLogin = fromLogin.getStringExtra("nameFromDb");
        nameOfUser.setText(fnFromLogin);


        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if (acct != null) {

//            Uri personPhoto = acct.getPhotoUrl();
//            Picasso.get().load(personPhoto).into(picOfUser);

        }


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_home:

                        Toast.makeText(getApplicationContext(), "This is dashboard", Toast.LENGTH_SHORT).show();

                        break;
                    case R.id.nav_jobs: {
//
//                        Intent browserIntent  = new Intent(Intent.ACTION_VIEW , Uri.parse(""));
//                        startActivity(browserIntent);
//
                        Intent intent = new Intent(Dashboard.this, JobLists.class);
                        intent.putExtra("globalName", fnFromLogin);
                        startActivity(intent);
                        finish();
                    }
                    break;

                    case R.id.nav_spes: {
                        Intent intent = new Intent(Dashboard.this, SpesApplication.class);
                        intent.putExtra("globalName", fnFromLogin);
                        startActivity(intent);
                        finish();
                    }
                    break;
                    case R.id.nav_resume: {
                        Intent intent = new Intent(Dashboard.this, ResumeMaker.class);
                        startActivity(intent);
                        finish();
                    }
                    break;
                    case R.id.nav_share: {

                        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                        sharingIntent.setType("text/plain");
                        String shareBody = "http://play.google.com/store/apps/detail?id=" + getPackageName();
                        String shareSub = "Try now";
                        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                        startActivity(Intent.createChooser(sharingIntent, "Share using"));

                    }
                    break;
//                    case R.id.nav_applicants: {
//                        Intent intent = new Intent(Dashboard.this, Profile.class);
//                        intent.putExtra("globalName", fnFromLogin);
//                        startActivity(intent);
////                        finish();
////                    }
//                    break;
                    case R.id.nav_logout: {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(Dashboard.this);
                        builder.setMessage("Are you sure to logout?");
                        builder.setCancelable(true);
                        builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(Dashboard.this, "Logging-out!", Toast.LENGTH_SHORT).show();
                                mAuth.signOut();
                                loadBar.startLoadingDialog();
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        loadBar.dismissDialog();
                                        FirebaseAuth.getInstance().signOut();
                                        GoogleSignIn.getClient(Dashboard.this, new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build())
                                                .signOut().addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                startActivity(new Intent(Dashboard.this, Landing.class));
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(Dashboard.this, "Signout failed", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                }, 3500);


                            }
                        });
                        builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                    break;
                    case R.id.nav_about: {
                        startActivity(new Intent(Dashboard.this, About.class));
                        finish();
                    }
                }
                return false;
            }
        });
        onBackPressed();
    }

    public void setUpToolbar() {
        drawerLayout = findViewById(R.id.drawerLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.desc, R.string.desc);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }

    public void logoutApp(final View view) {

        GoogleSignIn.getClient(this, new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build())
                .signOut().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                startActivity(new Intent(view.getContext(), Landing.class));
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Dashboard.this, "Signout failed", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(Dashboard.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_STORAGE_CODE);
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();


        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_STORAGE_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == READ_STORAGE_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {

    }

    int countOfName = 0;

    public void fetchingActivityFromFirebase() {



        DatabaseReference childrenCount = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("SpesApplication");
        if (childrenCount.equals("")) {
            childrenCount.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        countOfName = (int) snapshot.getChildrenCount();

                    } else {
                        countOfName = 0;
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
        });

        }
    }
}

