package com.example.thesisproject;

public class JobValues {
    String title;
    String desc;
    String jobtype;
    String startdate;
    String enddate;
    String requirements;

    public JobValues(String title, String desc, String jobtype, String startdate,String enddate,String requirements){
        this.title = title;
        this.desc = desc;
        this.jobtype = jobtype;
        this.startdate = startdate;
        this.enddate = enddate;
        this.requirements = requirements;


    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getJobtype() {
        return jobtype;
    }

    public void setJobtype(String jobtype) {
        this.jobtype = jobtype;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getRequirements() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }
}

