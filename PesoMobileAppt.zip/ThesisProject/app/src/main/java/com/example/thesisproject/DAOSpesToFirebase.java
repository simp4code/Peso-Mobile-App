package com.example.thesisproject;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DAOSpesToFirebase {
    private DatabaseReference databaseReference;

    public DAOSpesToFirebase(){
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = db.getReference("ApplicationConfirmation");
    }
    public Task<Void> add(DAOSpesValues daoUserData,String nameOfUser) {

        return databaseReference.child(nameOfUser).setValue(daoUserData);
    }

}
