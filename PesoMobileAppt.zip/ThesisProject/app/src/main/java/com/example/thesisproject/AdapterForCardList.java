package com.example.thesisproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterForCardList extends RecyclerView.Adapter<AdapterForCardList.MyViewHolder> {

    Context context ;
    ArrayList<JobTemplate> list;

    public AdapterForCardList(Context context, ArrayList<JobTemplate> list){
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.list_card,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        JobTemplate jot = list.get(position);
            holder.jobTitle.setText(jot.getTitle());
            holder.jobDescription.setText(jot.getDesc());
            holder.jobFirst.setText(jot.getStartdate());
            holder.jobType.setText(jot.getJobtype());
            holder.jobEnd.setText(jot.getEnddate());
            holder.jobRequirements.setText(jot.getRequirements());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView jobTitle,jobDescription,jobFirst,jobEnd,jobType,jobRequirements;

        public MyViewHolder(@NonNull View listView ){
                super(listView);
                jobTitle = listView.findViewById(R.id.job_title_value);
                jobDescription = listView.findViewById(R.id.job_description_value);
                jobFirst = listView.findViewById(R.id.job_start_value);
                jobEnd =listView.findViewById(R.id.job_end_value) ;
                jobType=listView.findViewById(R.id.job_type_value) ;
                jobRequirements=listView.findViewById(R.id.job_requirements_value);
        }
    }

}
