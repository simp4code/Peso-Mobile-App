package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class NumberToOtp extends AppCompatActivity {

    EditText enterNumber;
    Button getOtp;
    FirebaseAuth mAuth;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(NumberToOtp.this,Landing.class));
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number_to_otp);
        final ProgressBar progressBar = findViewById(R.id.pb);

        enterNumber = findViewById(R.id.input_mobile_number);
        getOtp = findViewById(R.id.get_otp_func);


        Intent getValues = getIntent();

        String username = getValues.getStringExtra("N");
        String email = getValues.getStringExtra("E");
        String contact = getValues.getStringExtra("C");
        String pass = getValues.getStringExtra("PW");
        String confirmpass = getValues.getStringExtra("PWC");


        enterNumber.setText(contact);


        getOtp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (enterNumber.getText().toString().trim().isEmpty()) {

                    Toast.makeText(NumberToOtp.this, "Enter number!", Toast.LENGTH_SHORT).show();
                    return;

                }

                progressBar.setVisibility(View.VISIBLE);
                getOtp.setVisibility(View.INVISIBLE);

                PhoneAuthProvider.getInstance().verifyPhoneNumber("+63" + enterNumber.getText().toString(),
                        60, TimeUnit.SECONDS,
                        NumberToOtp.this,
                        new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                progressBar.setVisibility(View.GONE);
                                getOtp.setVisibility(View.VISIBLE);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                progressBar.setVisibility(View.GONE);
                                getOtp.setVisibility(View.VISIBLE);
                                Toast.makeText(NumberToOtp.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String backend, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                super.onCodeSent(backend, forceResendingToken);
                                getOtp.setVisibility(View.VISIBLE);
                                Intent intent = new Intent(NumberToOtp.this, OtpVerification.class);
                                intent.putExtra("mobile", enterNumber.getText().toString());
                                //VALUES OF STRINGS
                                intent.putExtra("verificationId",backend);
                                intent.putExtra("NN", username);
                                intent.putExtra("EE", email);
                                intent.putExtra("CC", contact);
                                intent.putExtra("PPWW", pass);
                                intent.putExtra("PPWWCC", confirmpass);
                                startActivity(intent);
                            }
                        }
                );


            }
        });
    }
}