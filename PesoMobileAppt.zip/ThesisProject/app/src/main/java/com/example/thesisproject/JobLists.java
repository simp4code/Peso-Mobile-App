package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class JobLists extends AppCompatActivity implements  AdapterCardListForUser.recyclerClick{
    DrawerLayout drawerLayout;
    RecyclerView recyclerViewer;
    DatabaseReference databaseReference1;
    AdapterCardListForUser adapterCardListForUser;
    ArrayList<JobUserTemplate> listUser;



    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    FirebaseAuth mAuth;
    final LoadBar loadBar = new LoadBar(JobLists.this);
    final LoadImageFromGoogleAccount  loadImg = new LoadImageFromGoogleAccount(JobLists.this);
    Button applyNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_lists);
        setUpToolbar();
        navigationView = (NavigationView) findViewById(R.id.navigation_menu);
        mAuth = FirebaseAuth.getInstance();

        recyclerViewer = findViewById(R.id.joblisting_user);
        databaseReference1 = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("JobsListed");
        recyclerViewer.setHasFixedSize(true);
        recyclerViewer.setLayoutManager(new LinearLayoutManager(this));

        listUser = new ArrayList<>();
//        setAdapter();
       adapterCardListForUser = new AdapterCardListForUser(this,listUser, this);
       recyclerViewer.setAdapter(adapterCardListForUser);

        databaseReference1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    JobUserTemplate jotted = dataSnapshot.getValue(JobUserTemplate.class);
                    listUser.add(jotted);
                }
                adapterCardListForUser.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });





        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_home:

                        startActivity(new Intent(JobLists.this,Dashboard.class));
                        finish();

                        break;
                    case  R.id.nav_jobs:{
//
//                        Intent browserIntent  = new Intent(Intent.ACTION_VIEW , Uri.parse(""));
//                        startActivity(browserIntent);
//
                        Toast.makeText(getApplicationContext(),"This is jobs",Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    break;
                    case  R.id.nav_share:{

                        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                        sharingIntent.setType("text/plain");
                        String shareBody =  "http://play.google.com/store/apps/detail?id=" + getPackageName();
                        String shareSub = "Try now";
                        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                        startActivity(Intent.createChooser(sharingIntent, "Share using"));

                    }
                    break;
//                    case R.id.nav_applicants:{
//                        startActivity(new Intent(JobLists.this,Profile.class));
//                        finish();
//                    }
//                    break;
                    case R.id.nav_resume: {
                        Intent intent = new Intent(JobLists.this, ResumeMaker.class);
                        startActivity(intent);
                        finish();
                    }
                    break;
                    case R.id.nav_spes:{
                        startActivity(new Intent(JobLists.this, SpesApplication.class));
                        finish();
                    }
                    break;
                    case R.id.nav_logout:{
                        final AlertDialog.Builder builder = new AlertDialog.Builder(JobLists.this);
                        builder.setMessage("Are you sure to logout?");
                        builder.setCancelable(true);
                        builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(JobLists.this,"Logging-out!",Toast.LENGTH_SHORT).show();
                                mAuth.signOut();
                                loadBar.startLoadingDialog();
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        loadBar.dismissDialog();
                                        FirebaseAuth.getInstance().signOut();
                                        GoogleSignIn.getClient(JobLists.this,new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build())
                                                .signOut().addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                startActivity(new Intent(JobLists.this,Landing.class));
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(JobLists.this,"Signout failed",Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                },3500);



                            }
                        });
                        builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                    break;
                    case R.id.nav_about:{
                        startActivity(new Intent(JobLists.this,About.class));
                        finish();
                    }
                }
                return false;
            }
        });
    }

//    private void setOnClickListner() {
//
//        listener = new AdapterCardListForUser.RecyclerViewClickListener() {
//            @Override
//            public void onClick(View v, int position) {
//                Intent intent = new Intent(getApplicationContext(),ApplicationSubmission.class);
//                intent.putExtra("title", listUser.get(position).getTitle());
//                intent.putExtra("description", listUser.get(position).getDesc());
//                intent.putExtra("type", listUser.get(position).getJobtype());
//                intent.putExtra("startingdate", listUser.get(position).getStartdate());
//                intent.putExtra("duedate", listUser.get(position).getEnddate());
//                intent.putExtra("requirements", listUser.get(position).getRequirements());
//                startActivity(intent);
//
//            }
//        };
//
//    }

    public void setUpToolbar() {
        drawerLayout = findViewById(R.id.drawerLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.desc, R.string.desc);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }
    public void redirectToApplication(){

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(JobLists.this,Dashboard.class));
        finish();
    }

//    @Override
//    public void onSlideListenerClick(int position) {
//        listUser.get(position);
//        Intent intent = new Intent(this,ApplicationSubmission.class);
//        startActivity(intent);
//    }


    //        databaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
//                    JobTemplate jots = dataSnapshot.getValue(JobTemplate.class);
//                    lists.add(jots);
//                }
//                adapterForCardList.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });

    public void onItemClick(AdapterView<?> l, View v, int position, long id) {
        Log.i("HelloListView", "You clicked Item: " + id + " at position:" + position);
        // Then you start a new Activity via Intent
        Intent intent = new Intent();
        intent.setClass(this, ApplicationSubmission.class);
        intent.putExtra("position", position);
        // Or / And
        intent.putExtra("id", id);
        startActivity(intent);
    }

    @Override
    public void onClick(int position) {
       Log.d("TAG","onClicked: clicked");
        Intent intent = new Intent(this,ApplicationSubmission.class);
               intent.putExtra("title", listUser.get(position).getTitle());
               intent.putExtra("description", listUser.get(position).getDesc());
               intent.putExtra("type", listUser.get(position).getJobtype());
               intent.putExtra("startingdate", listUser.get(position).getStartdate());
               intent.putExtra("duedate", listUser.get(position).getEnddate());
               intent.putExtra("requirements", listUser.get(position).getRequirements());
               startActivity(intent);
    }

}