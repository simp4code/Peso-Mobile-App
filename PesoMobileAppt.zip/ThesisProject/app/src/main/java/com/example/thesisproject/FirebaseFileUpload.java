package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.List;

public class FirebaseFileUpload extends AppCompatActivity {
private Button upload;
private RecyclerView uploadList;
private static final int RESULT_LOAD_IMAGE1 = 1;
private List<String> fileNameList;
    private List<String> fileDoneList;
private UploadAdapter uploadAdapter;
private StorageReference storageReference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase_file_upload);
        storageReference = FirebaseStorage.getInstance().getReference();


        upload=findViewById(R.id.button);
        uploadList=findViewById(R.id.recycler);
        fileNameList = new ArrayList<>();
        uploadAdapter = new UploadAdapter(fileNameList,fileDoneList );
        uploadList.setLayoutManager(new LinearLayoutManager(this));
        uploadList.setHasFixedSize(true);
        uploadList.setAdapter(uploadAdapter);

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select File"),RESULT_LOAD_IMAGE1);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == RESULT_LOAD_IMAGE1&& resultCode == RESULT_OK){
            if(data.getClipData() != null){

                int totalItems = data.getClipData().getItemCount();
                for(int i =0;i < totalItems ;i++){
                    Uri fileUri = data.getClipData().getItemAt(i).getUri();
                    String fileName =getFileName(fileUri);
                    fileNameList.add(fileName);
                    uploadAdapter.notifyDataSetChanged();


                    //FILE UPLOAD TO DATABASE
                    StorageReference fileUpload = storageReference.child("Images").child(fileName);
                    final int finalI = i;

                    fileUpload.putFile(fileUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            fileDoneList.remove(finalI);
                            fileDoneList.add(finalI,"done");
                            uploadAdapter.notifyDataSetChanged();
//                            Toast.makeText(FirebaseFileUpload.this,"Files sent!",Toast.LENGTH_SHORT).show();

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });
                }

//                Toast.makeText(this,"Select multiple files",Toast.LENGTH_SHORT).show();

            }else if(data.getData() != null){
                Toast.makeText(this,"Select single file",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @SuppressLint("Range")
    public String getFileName(Uri uri){

        String result = null;
        if(uri.getScheme().equals("content")){
            Cursor cursor = getContentResolver().query(uri,null,null,null,null);
            try{
                if( cursor != null && cursor.moveToFirst()){
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));

                }

            }finally {
                cursor.close();
            }
        }
        if(result == null){
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if(cut != 1){
                result = result.substring(cut +1 );

            }
        }

        return result;

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(FirebaseFileUpload.this,JobDescriptionTab.class));
        finish();
    }
}