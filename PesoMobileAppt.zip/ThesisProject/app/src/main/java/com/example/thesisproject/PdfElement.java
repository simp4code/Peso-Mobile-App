package com.example.thesisproject;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class PdfElement extends RecyclerView.ViewHolder {
        public TextView nameText;
        public CardView nameContainer;

        public PdfElement(@NonNull View itemView){
            super(itemView);

            nameText = itemView.findViewById(R.id.pdfName);
            nameContainer = itemView.findViewById(R.id.pdfContainer);




        }


}
