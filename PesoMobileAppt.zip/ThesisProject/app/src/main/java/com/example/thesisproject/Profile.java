package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

public class Profile extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    FirebaseAuth mAuth;
    EditText fname,fage,fgender,faddress,fcontact;
    ImageView img;
    TextView edt;
    final LoadBar loadBar = new LoadBar(Profile.this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        //FIREBASE AUTH
//        mAuth = FirebaseAuth.getInstance();
//        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        String age;
//        String contact = firebaseAuth.getCurrentUser().getPhoneNumber();
        String gender;
        String address;


        //DECLARATION OF VARIABLE
        fname = findViewById(R.id.google_name);
        faddress = findViewById(R.id.google_location);
        fcontact = findViewById(R.id.google_contact);
        img = findViewById(R.id.image_container_card);
        edt = findViewById(R.id.edit_func);

        edt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fname.isEnabled();
            }
        });

        Intent fromDashboard = getIntent();
        String nameDb = fromDashboard.getStringExtra("globalName");
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if (acct != null) {
//            Uri personPhoto = acct.getPhotoUrl();
//            Picasso.get().load(personPhoto).into(img);
        }

        fname.setText(nameDb);
//        fcontact.setText(contact);
        //TOOL BAR
                setUpToolbar();
        navigationView = (NavigationView) findViewById(R.id.navigation_menu);

        //FUNCTION OF DRAWER
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {




            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_home:

                        startActivity(new Intent(Profile.this,Dashboard.class));
                        finish();
                        break;
                    case  R.id.nav_jobs:{
//
//                        Intent browserIntent  = new Intent(Intent.ACTION_VIEW , Uri.parse(""));
//                        startActivity(browserIntent);
//
                        startActivity(new Intent(Profile.this,JobLists.class));
                        finish();
                    }
                    break;
                    case R.id.nav_spes:{
                        startActivity(new Intent(Profile.this, SpesApplication.class));
                        finish();
                    }
                    break;
                    case  R.id.nav_share:{

                        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                        sharingIntent.setType("text/plain");
                        String shareBody =  "http://play.google.com/store/apps/detail?id=" + getPackageName();
                        String shareSub = "Try now";
                        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                        startActivity(Intent.createChooser(sharingIntent, "Share using"));

                    }
                    break;
//                    case R.id.nav_applicants:{
//                        Toast.makeText(getApplicationContext(),"This is profile already",Toast.LENGTH_SHORT).show();
//                    }
//                    break;
//
                    case R.id.nav_logout:{
                        final AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
                        builder.setMessage("Are you sure to logout?");
                        builder.setCancelable(true);
                        builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(Profile.this,"Logging-out!",Toast.LENGTH_SHORT).show();
                                mAuth.signOut();
                                loadBar.startLoadingDialog();
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        loadBar.dismissDialog();
                                        FirebaseAuth.getInstance().signOut();
                                        GoogleSignIn.getClient(Profile.this,new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build())
                                                .signOut().addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                startActivity(new Intent(Profile.this,Landing.class));
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(Profile.this,"Signout failed",Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                },3500);


                            }
                        });
                        builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                    break;
                    case R.id.nav_about:{
                        startActivity(new Intent(Profile.this,About.class));
                        finish();
                    }
                }
                return false;
            }
        });
        onBackPressed();

    }
    public void setUpToolbar() {
        drawerLayout = findViewById(R.id.drawerLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.desc, R.string.desc);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }

    @Override
    public void onBackPressed() {

    }
}