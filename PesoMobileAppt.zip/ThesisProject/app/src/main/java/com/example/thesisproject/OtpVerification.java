package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.FirebaseDatabase;

import java.util.concurrent.TimeUnit;

public class OtpVerification extends AppCompatActivity {
    private EditText input1, input2, input3, input4, input5, input6;
    Button confirm;
    private String verify;
    final LoadBar loadBar = new LoadBar(OtpVerification.this);
    FirebaseAuth firebaseAuth;

    @Override
    public void onBackPressed() {
        startActivity(new Intent(OtpVerification.this, NumberToOtp.class));
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_verification);
        TextView textView = findViewById(R.id.show_mobile_number);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("Peso App Registration", "Peso App", NotificationManager.IMPORTANCE_DEFAULT);
                NotificationManager manager = getSystemService(NotificationManager.class);
                manager.createNotificationChannel(channel);

        }


        textView.setText(String.format("+63-%s", getIntent().getStringExtra("mobile")));


        Intent valueGetter = getIntent();
        String ff = valueGetter.getStringExtra("NN");


        String gg = valueGetter.getStringExtra("EE");


        String hh = valueGetter.getStringExtra("CC");


        String ii = valueGetter.getStringExtra("PPWW");


        String jj = valueGetter.getStringExtra("PPWWCC");


        input1 = findViewById(R.id.otp1);
        input2 = findViewById(R.id.otp2);
        input3 = findViewById(R.id.otp3);
        input4 = findViewById(R.id.otp4);
        input5 = findViewById(R.id.otp5);
        input6 = findViewById(R.id.otp6);

        confirm = findViewById(R.id.get_top_func);
        final ProgressBar progessBar = findViewById(R.id.pbc);

        verify = getIntent().getStringExtra("verificationId");

        numberMove();


        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (input1.getText().toString().trim().isEmpty()
                        || input2.getText().toString().trim().isEmpty()
                        || input3.getText().toString().trim().isEmpty()
                        || input4.getText().toString().trim().isEmpty()
                        || input5.getText().toString().trim().isEmpty()
                        || input6.getText().toString().trim().isEmpty()) {
                    Toast.makeText(OtpVerification.this, "Enter valid code!", Toast.LENGTH_SHORT).show();
                    return;

                }
                String code = input1.getText().toString() + input2.getText().toString() +
                        input3.getText().toString() + input4.getText().toString() +
                        input5.getText().toString() + input6.getText().toString();

                DAOUserData daoUserData = new DAOUserData();

                if (verify != null) {
                    progessBar.setVisibility(View.VISIBLE);
                    confirm.setVisibility(View.INVISIBLE);
                    PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(
                            verify, code
                    );
                    FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progessBar.setVisibility(View.GONE);
                            confirm.setVisibility(View.VISIBLE);

                            //SAVING TO FIREBASE


                            if (task.isSuccessful()) {
                                Intent intent = new Intent(OtpVerification.this, UserLoggedIn.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

//                           firebaseAuth.createUserWithEmailAndPassword(gg,ii).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                               @Override
//                               public void onComplete(@NonNull Task<AuthResult> task) {
//                                       if(task.isSuccessful()){
//
//                                           UserValues userValues = new UserValues(ff,gg, hh,ii,jj);
//                                           FirebaseDatabase.getInstance().getReference("Users")
//                                                   .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
//                                                   .setValue(userValues).addOnCompleteListener(new OnCompleteListener<Void>() {
//                                               @Override
//                                               public void onComplete(@NonNull Task<Void> task) {
//                                                   if(task.isSuccessful()){
//
//                                                       Toast.makeText(getApplicationContext(),"Verified!",Toast.LENGTH_SHORT).show();
//
//                                                   }else{
//                                                       Toast.makeText(getApplicationContext(),"Try again!",Toast.LENGTH_SHORT).show();
//                                                   }
//                                               }
//                                           });
//
//                                                     startActivity(new Intent(OtpVerification.this,Landing.class));
//
//                                       }else{
//                                           Toast.makeText(getApplicationContext(),"Error!", Toast.LENGTH_SHORT).show();
//                                       }
//                               }
//                           });
//
//
//                            } else {
//                                Toast.makeText(OtpVerification.this, "Invalid verification code", Toast.LENGTH_SHORT).show();
//                            }
                                startActivity(intent);

                                //USER VERIFICATION
                                try {
                                    UserValues userValues = new UserValues(ff, gg,
                                            hh, ii, jj);

                                    daoUserData.add(userValues, ii).addOnSuccessListener(suc -> {

                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(getApplicationContext(), "OTP Verified!", Toast.LENGTH_LONG).show();
                                                //IN-APP NOTIFICATION

                                                NotificationCompat.Builder builderNotif = new NotificationCompat.Builder(OtpVerification.this, "Peso App Registration");
                                                builderNotif.setContentTitle("Peso App");
                                                builderNotif.setContentText("Hi!, " + ff + " you are now registered to Peso Mobile Application, sign-in now to \n check it's features.");
                                                builderNotif.setSmallIcon(R.drawable.pesologo);
                                                builderNotif.setAutoCancel(true);


                                                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(OtpVerification.this);
                                                managerCompat.notify(1, builderNotif.build());


                                            }
                                        }, 500);
                                    }).addOnFailureListener(er -> {
                                        Toast.makeText(OtpVerification.this, er.getMessage(), Toast.LENGTH_SHORT).show();
                                    });
                                } catch (Exception e) {
                                    Toast.makeText(OtpVerification.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                }


                            } else {
                                Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }



               /* if(!input1.getText().toString().trim().isEmpty() && !input2.getText().toString().trim().isEmpty() &&!input3.getText().toString().trim().isEmpty() &&!input4.getText().toString().trim().isEmpty() && !input5.getText().toString().trim().isEmpty() && !input6.getText().toString().trim().isEmpty()){
                    Toast.makeText(OtpVerification.this,"Verified!",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(OtpVerification.this,"Fill the blanks!",Toast.LENGTH_SHORT).show();
                }*/
            }
        });


        findViewById(R.id.resend_code).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PhoneAuthProvider.getInstance().verifyPhoneNumber("+63" + getIntent().getStringExtra("mobile"),
                        60, TimeUnit.SECONDS,
                        OtpVerification.this,
                        new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {

                                Toast.makeText(OtpVerification.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String news, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                verify = news;
                                Toast.makeText(OtpVerification.this, "Otp Sent!", Toast.LENGTH_SHORT).show();

                            }
                        }
                );
            }

        });
    }

    private void numberMove() {
        input1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    input2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    input3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    input4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    input5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        input5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    input6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}