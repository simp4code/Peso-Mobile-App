package com.example.thesisproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class AdapterPdf extends RecyclerView.Adapter<PdfElement> {

        private Context context;
        private List<File> pdffiles;


    @NonNull
    @Override
    public PdfElement onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PdfElement(LayoutInflater.from(context).inflate(R.layout.element_holder,parent,false));

    }

    @Override
    public void onBindViewHolder(@NonNull PdfElement holder, int position) {
            holder.nameText.setText(pdffiles.get(position).getName());
            holder.nameText.setSelected(true);


    }

    @Override
    public int getItemCount() {
        return pdffiles.size();
    }
}
