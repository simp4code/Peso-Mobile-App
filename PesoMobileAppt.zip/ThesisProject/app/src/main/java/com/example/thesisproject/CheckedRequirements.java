package com.example.thesisproject;

import java.io.Serializable;

public class CheckedRequirements implements Serializable {

    private String requirementsName;
    private boolean active;

    public CheckedRequirements(String requirementsName){
        this.requirementsName = requirementsName;
        this.active = true;
    }

    public CheckedRequirements(String requirementsName,boolean active){
        this.requirementsName = requirementsName;
        this.active  = true;
    }

    public String getRequirementsName(){
        return requirementsName;
    }
    public boolean isActive(){
        return active;
    }
    public void setActive(boolean active){
       this.active = active;

    }
    @Override
    public String toString(){
        return this.requirementsName;
    }

}
