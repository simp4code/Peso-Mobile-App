package com.example.thesisproject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.logging.Handler;

public class PopupDialog  {
    Activity activity;
    AlertDialog dialog;

    PopupDialog(Activity myActivity){

        activity = myActivity;
    }

    void startLoadingDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);

        LayoutInflater inflater = activity.getLayoutInflater();
        builder.setView(inflater.inflate(R.layout.load_dlg,null));
        builder.setCancelable(false);

        dialog = builder.create();
        dialog.show();

    }
    void dismissDialog(){
        dialog.dismiss();
    }
}
