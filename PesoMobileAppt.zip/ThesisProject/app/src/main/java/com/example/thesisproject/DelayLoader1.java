package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class DelayLoader1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delay_loader1);
        Intent intent = getIntent();
        String admin = intent.getStringExtra("adminLogin");
        if(admin.equals("adminValue")){
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(DelayLoader1.this,AdminDashboard.class));
                    finish();
                }
            },3500);
        }
    }
}