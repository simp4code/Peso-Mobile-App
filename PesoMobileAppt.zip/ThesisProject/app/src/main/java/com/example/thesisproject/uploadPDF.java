package com.example.thesisproject;

public class uploadPDF {

    public String username;
    public String url;

    public uploadPDF(){

    }

    public String getName() {
        return username;
    }

    public String getUrl() {
        return url;
    }

    public uploadPDF(String username, String url){
        this.username = username;
        this.url = url;

    }

}
