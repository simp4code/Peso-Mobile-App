package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.database.FirebaseDatabase;

import java.util.Arrays;
import java.util.Calendar;

public class AdminPanel extends AppCompatActivity {
Button setBtn,cancel;
FirebaseDatabase firebaseDatabase;
EditText mDateFormat1,mDateFormat2,title,details;
RadioGroup rg;
private RadioButton rd;
public static final String TAG = "ListViewRequirements";
CheckBox one,two,three,four;
    DatePickerDialog.OnDateSetListener onDateSetListener1,onDateSetListener2;
   private ListView requirementsView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        cancel = findViewById(R.id.cancel_set);
        setBtn = findViewById(R.id.input_set);
        mDateFormat1 = findViewById(R.id.dateFormat);
        mDateFormat2 = findViewById(R.id.dateFormat2);
        title = findViewById(R.id.job_title);
        details = findViewById(R.id.job_details);
        rg = findViewById(R.id.user_setting);
        int radioValue = rg.getCheckedRadioButtonId();
        this.requirementsView = (ListView) findViewById(R.id.requirements_list);

//        one = findViewById(R.id.chk1);
//        two = findViewById(R.id.chk2);
//        three = findViewById(R.id.chk3);
//        four = findViewById(R.id.chk4);
        this.requirementsView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        this.requirementsView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.i(TAG,"onItemClick" +position);
                CheckedTextView v =(CheckedTextView) view;
                boolean currentCheck = v.isChecked();
                CheckedRequirements cr = (CheckedRequirements)requirementsView.getItemAtPosition(position);
                cr.setActive(!currentCheck);

            }
        });
        this.initListViewData();

        mDateFormat1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        AdminPanel.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener1, year,month,day
                );

                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();

            }

        });
        mDateFormat2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        AdminPanel.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener2, year,month,day
                );

                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }

        });
        onDateSetListener1 = new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view , int year, int month, int day){
                month  = month + 1;
                String date = day  +"/"+month+"/"+year;
                mDateFormat1.setText(date);
            }
        };
       onDateSetListener2 = new DatePickerDialog.OnDateSetListener(){
           @Override
           public void onDateSet(DatePicker view , int year, int month, int day){
               month  = month + 1;
               String date = day  +"/"+month+"/"+year;
               mDateFormat2.setText(date);
           }
       };


        DAOJobValues daoJobValues = new DAOJobValues();


        SparseBooleanArray sp  = requirementsView.getCheckedItemPositions();
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < sp.size(); i++){
            if(sp.valueAt(i)==true){
                CheckedRequirements request =  (CheckedRequirements) requirementsView.getItemAtPosition(i);
                String s= request.getRequirementsName();
                sb = sb.append(","+s);
            }
        }
       setBtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

              try{
//                  RadioButton srg = findViewById(rg.getCheckedRadioButtonId());
//                  String selected = srg.getText().toString();
//                  String [] storage = new String [3];
//                  if(one.isChecked()){
//                      storage[0] = "Birth Certificate";
//                  }else{
//                      storage[0] = "";
//                  }
//
                  initListViewData();
                  int SelectedID = rg.getCheckedRadioButtonId();
                  rd = (RadioButton) findViewById(SelectedID);
                  SparseBooleanArray sp  = requirementsView.getCheckedItemPositions();
                  StringBuilder sb = new StringBuilder();
                  for(int i = 0; i < sp.size(); i++){
                      if(sp.valueAt(i)==true){
                          CheckedRequirements request =  (CheckedRequirements) requirementsView.getItemAtPosition(i);
                          String s = request.getRequirementsName();
                          sb = sb.append(" "+s);
                      }
                  }

                   JobValues jobValues = new JobValues(
                   title.getText().toString(), details.getText().toString(),rd.getText().toString() ,mDateFormat1.getText().toString() ,mDateFormat2.getText().toString(), sb.toString());
                   daoJobValues.add(jobValues, title.getText().toString()).addOnSuccessListener(suc->{
                       Handler handler = new Handler();
                       handler.postDelayed(new Runnable() {
                           @Override
                           public void run() {
                               Intent intent = new Intent(AdminPanel.this, AdminDashboard.class);
                               Toast.makeText(getApplicationContext(), "Job placed", Toast.LENGTH_LONG).show();
                               startActivity(intent);
                               finish();
                           }
                       },2000);
                   }).addOnFailureListener(er->{
                       Toast.makeText(AdminPanel.this,er.getMessage(),Toast.LENGTH_SHORT).show();
                   });

              }catch(Exception e) {


              }

           }
       });


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdminPanel.this, AdminDashboard.class));
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(AdminPanel.this,AdminDashboard.class));
    }

    private void initListViewData(){
        CheckedRequirements resumeFile = new CheckedRequirements("Resume");

        CheckedRequirements [] req = new CheckedRequirements[]{resumeFile};

        ArrayAdapter<CheckedRequirements> arrayAdapter = new ArrayAdapter<CheckedRequirements>(this,
                android.R.layout.simple_list_item_checked,req);
        this.requirementsView.setAdapter(arrayAdapter);
        for(int i = 0 ; i < req.length; i++){
            this.requirementsView.setItemChecked(i,req[i].isActive());

        }
    }
    public void getSelectedItemsInRequest(){

    }
}