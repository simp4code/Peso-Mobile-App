package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class UserLoggedIn extends AppCompatActivity {
    ProgressBar progressBar;
    Button login;
    TextInputEditText user, pass;
    Boolean valid = true;
    FirebaseAuth mAuth;
    final LoadBar loadBar = new LoadBar(UserLoggedIn.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_logged_in);

        progressBar = findViewById(R.id.progress_bar);
        progressBar.setVisibility(View.INVISIBLE);
        login = findViewById(R.id.login_user);
        user = findViewById(R.id.un);
        pass = findViewById(R.id.pw);
        mAuth = FirebaseAuth.getInstance();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loadBar.startLoadingDialog();
                checkField(user);
                checkField(pass);

                if (valid) {
                    final String emailVal = user.getText().toString();
                    final String passVal = pass.getText().toString();


//                    if (emailVal.equals("admin.peso@gmail.com") && passVal.equals("adminpassword")) {
//
//                        startActivity(new Intent(UserLoggedIn.this, AdminDashboard.class));
//                        finish();
//                    }

//                            String email = user.getText().toString().trim();
//                            String user_pass = pass.getText().toString().trim();
//                            FirebaseUser user = mAuth.getInstance().getCurrentUser();
//                            if(user != null){
//                                for(UserInfo profile: user.getProviderData()){
//                                    String providerIdOfUser = profile.getProviderId();
//                                    String uidProfile = profile.getUid();
//                                }
//                            }
                    String nameOfUser = "";
                    String emailOfUser = user.getText().toString().trim();
                    String passOfUser = pass.getText().toString().trim();
                    String adminEmail = "admin.peso@gmail.com";
                    Query checkUser = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("Users").orderByChild("password").equalTo(passOfUser);
                    checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                pass.setError(null);

                                String systemEmail = snapshot.child(passOfUser).child("email").getValue(String.class);
                                if (systemEmail.equals(emailOfUser)) {
                                    user.setError(null);
                                    String fn = snapshot.child(passOfUser).child("name").getValue(String.class);
                                    loadBar.dismissDialog();

                                    Intent intent = new Intent(UserLoggedIn.this, DelayLoader2.class);
                                    intent.putExtra("nameFromDatabase", fn);
                                    intent.putExtra("userLogin", "userValue");
                                    startActivity(intent);

                                }

                                if (systemEmail.equals(adminEmail)) {
                                    String fn = snapshot.child(passOfUser).child("name").getValue(String.class);

                                    loadBar.dismissDialog();
                                    Intent intent = new Intent(UserLoggedIn.this, DelayLoader1.class);
                                    intent.putExtra("adminLogin", "adminValue");
                                    startActivity(intent);
                                } else {
                                    progressBar.setVisibility(View.GONE);
                                    loadBar.dismissDialog();
//                                    Toast.makeText(UserLoggedIn.this, "Email/ pass not match", Toast.LENGTH_SHORT).show();
                                }
//                            } else if (emailOfUser.equals("") && passOfUser.equals("")){
//                                loadBar.dismissDialog();
//                                    Toast.makeText(getApplicationContext(),"Fields are blank!",Toast.LENGTH_SHORT).show();
//
//                            }
                            } else {
                                loadBar.dismissDialog();
                                progressBar.setVisibility(View.INVISIBLE);
                                login.setVisibility(View.VISIBLE);
                                Toast.makeText(UserLoggedIn.this, "No data exist", Toast.LENGTH_SHORT).show();

                            }

                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(UserLoggedIn.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }


        });
    }

    public boolean checkField(TextInputEditText fields) {
        if (fields.getText().toString().isEmpty()) {
            fields.setError("Empty!");
            progressBar.setVisibility(View.INVISIBLE);
            login.setVisibility(View.VISIBLE);
            loadBar.dismissDialog();
            valid = false;
        } else {
            valid = true;
            fields.setError(null);

        }
        return valid;
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(UserLoggedIn.this, Landing.class));
        finish();
    }

    private void userLoggedIn() {
        String email = user.getText().toString().trim();
        String pw = pass.getText().toString().trim();

        if (email.isEmpty()) {
            user.setError("Required");
            user.requestFocus();
            return;
        }
        if (pw.isEmpty()) {
            pass.setError("Required");
            pass.requestFocus();
            return;
        }

        mAuth.signInWithEmailAndPassword(email, pw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                    if (user.isEmailVerified()) {
                        startActivity(new Intent(UserLoggedIn.this, Dashboard.class));
                        finish();
                    } else {
                        user.sendEmailVerification();
                        Toast.makeText(getApplicationContext(), "Check your email to verify account!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Check your credentials!", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}