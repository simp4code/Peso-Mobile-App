package com.example.thesisproject;

public class JobUserTemplate {
    String title,desc,jobtype,startdate,enddate,requirements;
    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getJobtype() {
        return jobtype;
    }

    public String getStartdate() {
        return startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public String getRequirements() {
        return requirements;
    }
}
