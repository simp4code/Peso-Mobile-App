package com.example.thesisproject;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterCardListForUser extends RecyclerView.Adapter<AdapterCardListForUser.MyViewHolder> {
    Context context;
    ArrayList<JobUserTemplate> listUser;
    private recyclerClick listener1;

    public AdapterCardListForUser(Context context, ArrayList<JobUserTemplate> listUser,recyclerClick listener) {
        this.context = context;
        this.listUser = listUser;
        this.listener1 = listener;

    }

    @NonNull
    @Override
    public AdapterCardListForUser.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.list_card_for_user, parent, false);
        return new AdapterCardListForUser.MyViewHolder(v, listener1);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        JobUserTemplate jot = listUser.get(position);
        holder.jobTitle1.setText(jot.getTitle());
        holder.jobDescription1.setText(jot.getDesc());
        holder.jobFirst1.setText(jot.getStartdate());
        holder.jobType1.setText(jot.getJobtype());
        holder.jobEnd1.setText(jot.getEnddate());
        holder.jobRequirements1.setText(jot.getRequirements());

    }



    @Override
    public int getItemCount() {
        return listUser.size();
    }

    public  class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
//        private RecyclerViewClickListener listener;
        TextView jobTitle1,jobDescription1,jobFirst1,jobEnd1,jobType1,jobRequirements1;
        recyclerClick listener;

        public MyViewHolder(@NonNull View listView ,recyclerClick listener){
            super(listView);
            jobTitle1 = listView.findViewById(R.id.job_title_value_user);
            jobDescription1 = listView.findViewById(R.id.job_description_value_user);
            jobFirst1 = listView.findViewById(R.id.job_start_value_user);
            jobEnd1 =listView.findViewById(R.id.job_end_value_user) ;
            jobType1=listView.findViewById(R.id.job_type_value_user) ;
            jobRequirements1=listView.findViewById(R.id.job_requirements_value_user);
            this.listener = listener;
            listView.setOnClickListener(this);
        }


        @Override
        public void onClick(View v) {
            listener.onClick(getAdapterPosition());

        }
    }
    public interface recyclerClick{
        void onClick(int position);
    }


}
