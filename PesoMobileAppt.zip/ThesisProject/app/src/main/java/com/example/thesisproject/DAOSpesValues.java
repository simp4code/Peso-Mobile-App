package com.example.thesisproject;

public class DAOSpesValues {
    public String getDateOfApplication() {
        return dateOfApplication;
    }

    public void setDateOfApplication(String dateOfApplication) {
        this.dateOfApplication = dateOfApplication;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEducational() {
        return educational;
    }

    public void setEducational(String educational) {
        this.educational = educational;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getfOccupation() {
        return fOccupation;
    }

    public void setfOccupation(String fOccupation) {
        this.fOccupation = fOccupation;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getmOccupation() {
        return mOccupation;
    }

    public void setmOccupation(String mOccupation) {
        this.mOccupation = mOccupation;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getRelatives() {
        return relatives;
    }

    public void setRelatives(String relatives) {
        this.relatives = relatives;
    }

    public String getParentSalary() {
        return parentSalary;
    }

    public void setParentSalary(String parentSalary) {
        this.parentSalary = parentSalary;
    }

    public String getYearsInTaguig() {
        return yearsInTaguig;
    }

    public void setYearsInTaguig(String yearsInTaguig) {
        this.yearsInTaguig = yearsInTaguig;
    }

    public String getSiblings() {
        return siblings;
    }

    public void setSiblings(String siblings) {
        this.siblings = siblings;
    }

    public String getTriedSpes() {
        return triedSpes;
    }

    public void setTriedSpes(String triedSpes) {
        this.triedSpes = triedSpes;
    }

    public String getDisabilities() {
        return disabilities;
    }

    public void setDisabilities(String disabilities) {
        this.disabilities = disabilities;
    }

    public String getExpectations() {
        return expectations;
    }

    public void setExpectations(String expectations) {
        this.expectations = expectations;
    }

    public String getHouseSelect() {
        return houseSelect;
    }

    public void setHouseSelect(String houseSelect) {
        this.houseSelect = houseSelect;
    }

    String dateOfApplication, fullname,age, birthday, gender, address, educational
            , skills, course, fatherName, fOccupation,
            motherName, mOccupation, schedule, relatives,
            parentSalary, yearsInTaguig, siblings, triedSpes, disabilities, expectations,houseSelect;

    public DAOSpesValues(String c1, String c2, String c3, String c4,String  c5,String  c6,String c7,String
            c8,String c9,String c10,String c11,String c12,String c13,String c14,String c15,
                         String c16, String c17,String c18,String c19,String c20,String c21,String cspinner){


        this.dateOfApplication = c1;
        this.fullname = c2;
        this.birthday = c3;
        this.gender = c4;
        this.age = c5;
        this.address = c6;
        this.educational = c7;
        this.skills = c8;
        this.course = c9;
        this.fatherName = c10;
        this.fOccupation = c11;
        this.motherName = c12;
        this.mOccupation = c13;
        this.schedule = c14;
        this.relatives = c15;
        this.parentSalary = c16;
        this.yearsInTaguig = c17;
        this.siblings = c18;
        this.triedSpes = c19;
        this.disabilities = c20;
        this.expectations = c21;
        this.houseSelect = cspinner;

    }

}
