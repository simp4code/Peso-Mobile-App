package com.example.thesisproject;

import android.app.Activity;
import android.net.Uri;
import android.widget.ImageView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

public class LoadImageFromGoogleAccount {
    Activity activity;
    FirebaseAuth mAuth;
    ImageView picOfUser;


    LoadImageFromGoogleAccount(Activity myActivity){
        activity = myActivity;
    }

    void loadImageFromGoogle(){

    }

}
