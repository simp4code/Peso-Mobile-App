package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

public class SignUpUserWithGoogle extends AppCompatActivity {
Button signup;
FirebaseAuth mAuth;
TextInputEditText fullname,email,pass,contact,confirmpass;
Boolean valid = false;
ProgressBar loadingqueue;
final LoadBar loadBar = new LoadBar(SignUpUserWithGoogle.this);





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_user_with_google);

        //DECLARATION OF VARIABLES
        final ProgressBar progressBar = findViewById(R.id.progress_reg);
         signup = findViewById(R.id.user_sign_up_to_db);
         fullname= findViewById(R.id.user_name);
         email= findViewById(R.id.user_email);
         pass= findViewById(R.id.user_pass);
         contact= findViewById(R.id.user_contact);
         confirmpass= findViewById(R.id.user_confirm_pass);
         loadingqueue = findViewById(R.id.progress_hide);


         loadingqueue.setVisibility(View.INVISIBLE);
        //GETTING FIREBASE INSTANCE
        mAuth = FirebaseAuth.getInstance();

        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        fullname.setText(firebaseAuth.getCurrentUser().getDisplayName());
        email.setText(firebaseAuth.getCurrentUser().getEmail());


        Log.d("tag","onCreate: "+ "USER IS SIGNED IN");
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if (acct != null) {

        }

        //USER ENTITIES

//        DAOUserData daoUserData = new DAOUserData();

        //SIGNING UP
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        signup.setVisibility(View.INVISIBLE);
                        loadingqueue.setVisibility(View.VISIBLE);

                        String firstValueContainer = dataInput(contact);

                        //09195131986
                        String shorten = firstValueContainer.substring(1,11);

                        String a = fullname.getText().toString().trim();
                        String b = email.getText().toString().trim();
                        String c = contact.getText().toString().trim();
                        String d =pass.getText().toString().trim();
                        String e = confirmpass.getText().toString().trim();

                        if(TextUtils.isEmpty(a)){
                            fullname.setError("Required!");
                            return;
                        }
                        if(TextUtils.isEmpty(b)){
                            email.setError("Required!");
                            return;
                        }
                        if(TextUtils.isEmpty(c)){
                            contact.setError("Required!");
                            return;
                        }
                        if(d.length() < 7 ){
                            pass.setError("Password too short!");
                            return;
                        }
                        if(TextUtils.isEmpty(e)){
                            confirmpass.setError("Required!");
                            return;
                        }

                        Intent intent  = new Intent(SignUpUserWithGoogle.this, NumberToOtp.class);
                        intent.putExtra("N",dataInput(fullname));
                        intent.putExtra("E",dataInput(email));
                        intent.putExtra("C",shorten);
                        intent.putExtra("PW",dataInput(pass));
                        intent.putExtra("PWC",dataInput(confirmpass));
                        startActivity(intent);
//                        mAuth.signOut();

                    }
                },1000);
            }
        });




    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(SignUpUserWithGoogle.this,Landing.class));
        finish();
    }

//FIELD CHECKING
    public boolean checkField(TextInputEditText fields) {
        if (fields.getText().toString().isEmpty()) {
            fields.setError("Empty!");
            valid = false;
        } else {
            valid = true;
        }
        return valid;

    }
    //VALUE TRIMMING

    public  String dataInput(TextView t){
        return t.getText().toString().trim();
    }
}