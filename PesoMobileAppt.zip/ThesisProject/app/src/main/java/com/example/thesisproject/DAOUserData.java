package com.example.thesisproject;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DAOUserData {
    private DatabaseReference databaseReference;

    public DAOUserData(){
        FirebaseDatabase db  = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/");
        databaseReference = db.getReference("Users");

    }
    public Task<Void> add(UserValues daoUserData,String keyValue){

        return  databaseReference.child(keyValue).setValue(daoUserData);
    }

    /*public Task<Void> update(String key , HashMap<String,Object> hashMap){

      return  databaseReference.child(key).updateChildren(hashMap);

    }*/





}
