package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.telecom.PhoneAccountHandle;
import android.widget.Toast;

public class DelayLoader extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delay_loader);

        Intent intent = getIntent();

        String cont = intent.getStringExtra("startLoad");




        if(cont.equals("valueForLoading")){
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    startActivity(new Intent(DelayLoader.this,SignUpUserWithGoogle.class));
                    finish();
                }
            },3500);
        }




    }
}