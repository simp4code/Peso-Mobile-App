package com.example.thesisproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class DelayLoader2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delay_loader2);
        Intent intent = getIntent();
        String user = intent.getStringExtra("userLogin");
        String nextPager = intent.getStringExtra("nameFromDatabase");
        if(user.equals("userValue")) {
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(DelayLoader2.this, Dashboard.class);
                    intent.putExtra("nameFromDb", nextPager);
                    startActivity(intent);

                    finish();
                }
            }, 3500);
        }
    }
}