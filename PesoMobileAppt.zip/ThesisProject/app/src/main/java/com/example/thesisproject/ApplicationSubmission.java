package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class ApplicationSubmission extends AppCompatActivity {
    Button at, sub;
    private static final int RESULT_LOAD_IMAGE = 1;
    TextView fn;
    EditText edt;
    FirebaseStorage storage1;
    FirebaseDatabase database1;
    StorageReference storageReference1;
    DatabaseReference databaseReference1;
    ProgressDialog progressDialog;
    TextView t, d, f, e, ty, r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_application_submission);
        at = findViewById(R.id.attach_file);
        sub = findViewById(R.id.submit_file);
        fn = findViewById(R.id.file_namevalue);
        edt = findViewById(R.id.edit_value);


        t = findViewById(R.id.job_title_value_user1);
        d = findViewById(R.id.job_description_value_user1);
        f = findViewById(R.id.job_start_value_user1);
        e = findViewById(R.id.job_end_value_user1);
        ty = findViewById(R.id.job_type_value_user1);
        r = findViewById(R.id.job_requirements_value_user1);

        String uTitle = "Not set";
        String uDesc = "Not set";
        String uFirstDate = "Not set";
        String uEndDate = "Not set";
        String uType = "Not set";
        String uRequirements = "Not set";

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            uTitle = extras.getString("title");
            uDesc = extras.getString("description");
            uFirstDate = extras.getString("type");
            uEndDate = extras.getString("startingdate");
            uType = extras.getString("duedate");
            uRequirements = extras.getString("requirements");
        }
        t.setText(uTitle);
        d.setText(uDesc);
        f.setText(uFirstDate);
        e.setText(uEndDate);
        ty.setText(uType);
        r.setText(uRequirements);


        storage1 = FirebaseStorage.getInstance();
        storageReference1 = FirebaseStorage.getInstance().getReference();
        databaseReference1 = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("JobApplication");

        at.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectPdf();
            }
        });

    }

    private void selectPdf() {
        Intent pdfIntent = new Intent();
        pdfIntent.setType("application/pdf");
        pdfIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(pdfIntent, "Select PDF"), RESULT_LOAD_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null) {
            fn.setText(data.getDataString()
                    .substring(data.getDataString().lastIndexOf("/") + 1));
            sub.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    uploadFile(data.getData());

                }
            });


        } else {
            Toast.makeText(getApplicationContext(), "Please select a file", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadFile(Uri pdfUri) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("File loading..");
        progressDialog.show();
        //FIELDS UPLOADS

        //TEXTFIELDS VALUE
        StorageReference reference = storageReference1.child(edt.getText().toString() + "" + System.currentTimeMillis() + ".pdf");
        reference.putFile(pdfUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isComplete()) ;
                        Uri uri = uriTask.getResult();
                        putPDF putPDF = new putPDF(edt.getText().toString(), uri.toString());
                        databaseReference1.child(edt.getText().toString()).setValue(putPDF);
                        Toast.makeText(getApplicationContext(), "Application sent!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ApplicationSubmission.this, Dashboard.class);
                        intent.putExtra("valueName",edt.getText().toString());
                        progressDialog.dismiss();
                        startActivity(intent);
                        finish();

                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                double currentProgress = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                progressDialog.setMessage("File Uploading : " + (int) currentProgress + "%");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Application failed!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}