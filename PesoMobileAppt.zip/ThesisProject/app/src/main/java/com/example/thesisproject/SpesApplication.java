package com.example.thesisproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class SpesApplication extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final int RESULT_LOAD_IMAGE = 1;
public static  TextInputEditText a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21;
    Spinner spinner;
    String[] house = {"Owner", "Tenant", "Living in relatives"};
    private Button up, sel;
    RecyclerView recyclerView;
    private List<String> filelistname, filelistdone;
    private UploadAdapter uploadAdapter;
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    final LoadBar loadBar = new LoadBar(SpesApplication.this);
    Boolean valid = true;
    Uri pdfUri;
    String spinnerValue;
    FirebaseStorage storage;
    FirebaseDatabase database;
    StorageReference storageReference;
    DatabaseReference databaseReference;
    ProgressDialog progressDialog;
    TextView txtVal;
    final Calendar calendar = Calendar.getInstance();
    int year = calendar.get(Calendar.YEAR);
    int month = calendar.get(Calendar.MONTH);
    int day = calendar.get(Calendar.DAY_OF_MONTH);
    DatePickerDialog.OnDateSetListener onDateSetListener11,onDateSetListener22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spes_application);
        //SPES APPLICATION FIELDS
        a1 = findViewById(R.id.t1);
        a2 = findViewById(R.id.t2);
        a3 = findViewById(R.id.t3);
        a4 = findViewById(R.id.t4);
        a5 = findViewById(R.id.t5);
        a6 = findViewById(R.id.t6);
        a7 = findViewById(R.id.t7);
        a8 = findViewById(R.id.t8);
        a9 = findViewById(R.id.t9);
        a10 = findViewById(R.id.t10);
        a11 = findViewById(R.id.t11);
        a12 = findViewById(R.id.t12);
        a13 = findViewById(R.id.t13);
        a14 = findViewById(R.id.t14);
        a15 = findViewById(R.id.t15);
        a16 = findViewById(R.id.t16);
        a17 = findViewById(R.id.t17);
        a18 = findViewById(R.id.t18);
        a19 = findViewById(R.id.t19);
        a20 = findViewById(R.id.t20);
        a21 = findViewById(R.id.t21);
        //BUTTONS
        up = findViewById(R.id.upload_files);
        txtVal = findViewById(R.id.textValueOfPdf);
//
//        SimpleDateFormat dateForSpes = new SimpleDateFormat("dd/MM/yyyy");
//        Date date = new Date();
//        String nowDate = dateForSpes.format(date);
//        //CURRENT DATE STAMP
//        a1.setText(nowDate);
        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        SpesApplication.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener11, year,month,day
                );

                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();

            }

        });
                a3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        SpesApplication.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener22, year,month,day
                );

                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();

            }

        });



        onDateSetListener11 = new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view , int year, int month, int day){
                month  = month + 1;
                String date = day  +"/"+month+"/"+year;
                a1.setText(date);
            }
        };
        onDateSetListener22 = new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view , int year, int month, int day){
                month  = month + 1;
                String date = day  +"/"+month+"/"+year;
                a3.setText(date);
            }
        };


        storage = FirebaseStorage.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        databaseReference = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("SpesApplication");
        setUpToolbar();
        navigationView = (NavigationView) findViewById(R.id.navigation_menu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_home:

                        startActivity(new Intent(SpesApplication.this, Dashboard.class));
                        finish();
                        break;
                    case R.id.nav_jobs: {
//
//                        Intent browserIntent  = new Intent(Intent.ACTION_VIEW , Uri.parse(""));
//                        startActivity(browserIntent);
//
                        startActivity(new Intent(SpesApplication.this, JobLists.class));
                        finish();
                    }
                    break;
                    case R.id.nav_spes: {

                    }
                    break;
                    case R.id.nav_resume: {
                        Intent intent = new Intent(SpesApplication.this, ResumeMaker.class);
                        startActivity(intent);
                        finish();
                    }
                    break;
                    case R.id.nav_share: {

                        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                        sharingIntent.setType("text/plain");
                        String shareBody = "http://play.google.com/store/apps/detail?id=" + getPackageName();
                        String shareSub = "Try now";
                        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                        startActivity(Intent.createChooser(sharingIntent, "Share using"));

                    }
                    break;
//                    case R.id.nav_applicants: {
//                        startActivity(new Intent(SpesApplication.this, Profile.class));w
//                        finish();
//                    }
//                    break;
                    case R.id.nav_logout: {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(SpesApplication.this);
                        builder.setMessage("Are you sure to logout?");
                        builder.setCancelable(true);
                        builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(SpesApplication.this, "Logging-out!", Toast.LENGTH_SHORT).show();
                                loadBar.startLoadingDialog();
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        loadBar.dismissDialog();
                                        startActivity(new Intent(SpesApplication.this, Landing.class));
                                        finish();
                                    }
                                }, 3500);


                            }
                        });
                        builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                    break;
                }
                return false;
            }
        });


        up = findViewById(R.id.upload_files);
        sel = findViewById(R.id.select_files);
        recyclerView = findViewById(R.id.recyler_uploads);
        spinner = findViewById(R.id.spinner_values);
        spinner.setOnItemSelectedListener(this);

        filelistname = new ArrayList<>();
        uploadAdapter = new UploadAdapter(filelistname, filelistdone);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(uploadAdapter);


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, house);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);


        sel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectPdf();
            }
        });
    }

    private void uploadFile(Uri pdfUri) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("File loading..");
        progressDialog.show();
        //FIELDS UPLOADS
        uploadFormSPES();
        //TEXTFIELDS VALUE
        StorageReference reference = storageReference.child(a2.getText().toString() + "" + System.currentTimeMillis() + ".pdf");
        reference.putFile(pdfUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isComplete()) ;
                        Uri uri = uriTask.getResult();
                        txtVal.setText("");
                        putPDF putPDF = new putPDF(a2.getText().toString(), uri.toString());
                        databaseReference.child(a2.getText().toString()).setValue(putPDF);
                        Toast.makeText(getApplicationContext(), "Application sent!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SpesApplication.this, Dashboard.class);
                        progressDialog.dismiss();
                        startActivity(intent);
                        finish();

                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                double currentProgress = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                progressDialog.setMessage("File Uploading : " + (int) currentProgress + "%");
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Application failed!", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void userDetailsUpload() {


    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//        Toast.makeText(getApplicationContext(), house[position], Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null) {
            txtVal.setText(data.getDataString()
                    .substring(data.getDataString().lastIndexOf("/") + 1));
            up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    uploadFile(data.getData());

                }
            });


        } else {
            Toast.makeText(getApplicationContext(), "Please select a file", Toast.LENGTH_SHORT).show();
        }
    }

    //    userDetailsUpload();
    @SuppressLint("Range")
//    public String getFileName(Uri uri) {
//
//        String result = null;
//        if (uri.getScheme().equals("content")) {
//            Cursor cursor = getContentResolver().query(uri, null, null, null, null, null);
//            try {
//                if (cursor != null && cursor.moveToFirst()) {
//                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
//                }
//            } finally {
//                cursor.close();
//            }
//        }
//        if (result == null) {
//            result = uri.getPath();
//            int cut = result.lastIndexOf('/');
//            if (cut != -1) {
//                result = result.substring(cut + 1);
//            }
//        }
//        return result;
//    }

    public void setUpToolbar() {
        drawerLayout = findViewById(R.id.drawerLayout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.desc, R.string.desc);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }

    public boolean checkField(TextInputEditText fields) {
        if (fields.getText().toString().isEmpty()) {
            fields.setError("Empty!");
            valid = false;
            Toast.makeText(getApplicationContext(),"Empty fields!",Toast.LENGTH_SHORT).show();
        } else {
            valid = true;
            fields.setError(null);

        }
        return valid;
    }

    private void selectPdf() {
        Intent pdfIntent = new Intent();
        pdfIntent.setType("application/pdf");
        pdfIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(pdfIntent, "Select PDF"), RESULT_LOAD_IMAGE);
    }

    public void uploadFormSPES() {

        checkField(a1);
        checkField(a2);
        checkField(a3);
        checkField(a4);
        checkField(a5);
        checkField(a6);
        checkField(a7);
        checkField(a8);
        checkField(a9);
        checkField(a10);
        checkField(a11);
        checkField(a12);
        checkField(a13);
        checkField(a14);
        checkField(a15);
        checkField(a16);
        checkField(a17);
        checkField(a18);
        checkField(a19);
        checkField(a20);
        checkField(a21);
        spinnerValue = spinner.getSelectedItem().toString();

        DAOSpesValues daoSpesValues = new DAOSpesValues(
                a1.getText().toString().trim(),
                a2.getText().toString().trim(),
                a3.getText().toString().trim(),
                a4.getText().toString().trim(),
                a5.getText().toString().trim(),
                a6.getText().toString().trim(),
                a7.getText().toString().trim(),
                a8.getText().toString().trim(),
                a9.getText().toString().trim(),
                a10.getText().toString().trim(),
                a11.getText().toString().trim(),
                a12.getText().toString().trim(),
                a13.getText().toString().trim(),
                a14.getText().toString().trim(),
                a15.getText().toString().trim(),
                a16.getText().toString().trim(),
                a17.getText().toString().trim(),
                a18.getText().toString().trim(),
                a19.getText().toString().trim(),
                a20.getText().toString().trim(),
                a21.getText().toString().trim(),
                spinnerValue
        );
        DAOSpesToFirebase daoSpesToFirebase = new DAOSpesToFirebase();
        daoSpesToFirebase.add(daoSpesValues, a2.getText().toString().trim()).addOnSuccessListener(suc -> {

        }).addOnFailureListener(er -> {
            Toast.makeText(getApplicationContext(), "Sending failed!", Toast.LENGTH_LONG).show();
        });
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(SpesApplication.this,Dashboard.class));
        finish();
    }
}


