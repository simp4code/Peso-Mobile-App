package com.example.thesisproject;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DetailsRegistration extends AppCompatActivity {
    TextInputEditText email, pass,confirmpass;
    Button cncl,reg;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_registration);
        email = findViewById(R.id.emailFromGoogle);
        pass = findViewById(R.id.pass);
        confirmpass = findViewById(R.id.confirm_pass);
        cncl = findViewById(R.id.cancel_btn_sign);
        reg = findViewById(R.id.register_now_sign);
        cncl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DetailsRegistration.this,Landing.class));
                finish();
            }
        });
        Intent valueFromLogin = getIntent();
        String emailUsed = valueFromLogin.getStringExtra("userEmail");

        email.setText(emailUsed);


        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(pass.getText().toString().length() < 7){
                    pass.setError("Password must be 8 characters");
                }else if (!confirmpass.getText().toString().equals(pass.getText().toString())){
                    confirmpass.setError("Password not match");
                }else if(pass.getText().toString().isEmpty()){
                    pass.setError("Required");
                }else if(confirmpass.getText().toString().isEmpty()){
                    confirmpass.setError("Required");
                }else{

                    mAuth = FirebaseAuth.getInstance();
                    mAuth.createUserWithEmailAndPassword(email.getText().toString(),confirmpass.getText().toString())
                            .addOnCompleteListener(DetailsRegistration.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    Toast.makeText(getApplicationContext(),"Success!",Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(DetailsRegistration.this,Dashboard.class));
                                    finish();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(),"Error!",Toast.LENGTH_SHORT).show();
                        }
                    });





                }
            }
        });

        }

}