package com.example.thesisproject;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

    public class DAOJobValues {
        private DatabaseReference databaseReference;

        public DAOJobValues() {
            FirebaseDatabase db = FirebaseDatabase.getInstance("https://projectthesisfinal-d4909-default-rtdb.asia-southeast1.firebasedatabase.app/");
            databaseReference = db.getReference("JobsListed");

        }

        public Task<Void> add(JobValues daoUserData,String jobtitle) {

            return databaseReference.child(jobtitle).setValue(daoUserData);
        }


    }
